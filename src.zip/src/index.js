const CarService = require('./CarService');

exports.handler = async (event) => {
  const response = {};
  try {
    // let requestBody = event.body;
    // let { searchText, filterBy } = requestBody;

    /* Validate the required request params */
    // if (!utils.isValidateInput(searchText) || !utils.isValidateInput(filterBy)) {
    //   throw new Error("Invalid request body");
    // }

    // Get search results
    const searchResult = await CarService.getCars(event.queryStringParameters);

    // if (searchResult && searchResult.length > 0) {
    response.data = searchResult;
    response.message = 'Results fetched now from a zip!';
    // } else {
    //   response.data = searchResult || [];
    //   response.message = "No results found";
    // }
    response.code = 200;
    return response;
  } catch (error) {
    response.code = 400;

    if (error) {
      response.ErrorMessages = [error.message, JSON.stringify(error)];
    }

    return response;
  }
};
